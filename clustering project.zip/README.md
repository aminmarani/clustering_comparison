# clustering_comparison
This repository implements K-means and Spectral clustering in python with no use of preexisting models

How to run:

python clustering.py [datafile] [method]

datafile: cho.text / iyer.txt
method: single_run / compare

----------------------------------------------------------
single_run: one run of Kmeans and Spectral with pre-set K
compare: running Kmeans and Spectral Clustering with K from 2 to 20
